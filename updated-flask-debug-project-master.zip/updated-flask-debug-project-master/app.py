from debug_project_app import app,routes

if __name__ == "__main__":
    app.run(debug = True)